package com.bottomline.paymentplan.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Paymentplan {
	@Id
	@GeneratedValue
	Long paymentId;

	@Column
	Double totalAmount;

	@Column
	Integer numberOfPayment;

	@Column
	Double regularPaymentAmount;

	public Long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Integer getNumberOfPayment() {
		return numberOfPayment;
	}

	public void setNumberOfPayment(Integer numberOfPayment) {
		this.numberOfPayment = numberOfPayment;
	}

	public Double getRegularPaymentAmount() {
		return regularPaymentAmount;
	}

	public void setRegularPaymentAmount(Double regularPaymentAmount) {
		this.regularPaymentAmount = regularPaymentAmount;
	}

	public Double getLastAmount() {
		return lastAmount;
	}

	public void setLastAmount(Double lastAmount) {
		this.lastAmount = lastAmount;
	}


	@Column
	Double lastAmount;

}
