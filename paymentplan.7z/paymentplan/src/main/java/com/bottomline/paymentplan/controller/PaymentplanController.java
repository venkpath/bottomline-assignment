package com.bottomline.paymentplan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.paymentplan.model.Paymentplan;
import com.bottomline.paymentplan.service.PaymentplanService;

/**
 * This class will create and get payment plan details
 *
 * @author P Venkata Prasanth
 */

@RestController
@RequestMapping("/api/v1/paymentplan")
public class PaymentplanController {

	@Autowired
	PaymentplanService paymentplanService;

	public PaymentplanController() {
	}

	/**
	 * getAllPaymentplans method is used to get all payment plans
	 *
	 * @return list of payment plans
	 */
	@GetMapping("/getAllPaymentplans")
	public ResponseEntity<List<Paymentplan>> getAllPaymentplans() {
		List<Paymentplan> todos = paymentplanService.getAllPaymentplans();
		return new ResponseEntity<>(todos, HttpStatus.OK);
	}

	/**
	 * getPaymentplan method is used get the selected payment plan
	 *
	 * @param paymentId
	 * @return selected payment plan details
	 */
	@GetMapping({ "/getPaymentplan/{paymentId}" })
	public ResponseEntity<Paymentplan> getPaymentplan(@PathVariable Long paymentId) {
		return new ResponseEntity<>(paymentplanService.getPaymentplan(paymentId), HttpStatus.OK);
	}

	/**
	 * createPaymentPlan method is used create the payment plan
	 *
	 * @param totalAmount
	 * @param numberOfPayment
	 * @return created payment plan
	 */
	@PostMapping("/createPaymentPlan")
	public ResponseEntity<Paymentplan> createPaymentPlan(@RequestParam Double totalAmount,
			@RequestParam Integer numberOfPayment) {
		return new ResponseEntity<>(paymentplanService.createPaymentPlan(totalAmount, numberOfPayment),
				HttpStatus.CREATED);
	}
}
