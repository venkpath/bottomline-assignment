package com.bottomline.paymentplan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentplanApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentplanApplication.class, args);
	}

}
