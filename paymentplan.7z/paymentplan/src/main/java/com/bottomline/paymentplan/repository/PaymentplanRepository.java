package com.bottomline.paymentplan.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bottomline.paymentplan.model.Paymentplan;

@Repository
public interface PaymentplanRepository extends JpaRepository<Paymentplan, Long> {

}
