package com.bottomline.paymentplan.service;

import java.text.DecimalFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bottomline.paymentplan.model.Paymentplan;
import com.bottomline.paymentplan.repository.PaymentplanRepository;

/**
 * This class is the implementation class for PaymentplanService
 *
 * @author P Venkata Prasanth
 */

@Service
public class PaymentplanServiceImpl implements PaymentplanService {

	@Autowired
	PaymentplanRepository paymentplanRepository;

	@Override
	public List<Paymentplan> getAllPaymentplans() {

		return paymentplanRepository.findAll();
	}

	@Override
	public Paymentplan getPaymentplan(long paymentId) {
		return paymentplanRepository.findById(paymentId).orElse(new Paymentplan());
	}

	@Override
	public Paymentplan createPaymentPlan(Double totalAmount, Integer numberOfPayment) {
		Paymentplan paymentplan = new Paymentplan();
		paymentplan.setTotalAmount(totalAmount);
		paymentplan.setNumberOfPayment(numberOfPayment);
		Double regularPayment = (double) (totalAmount / numberOfPayment);
		DecimalFormat decimalFormat = new DecimalFormat("#.00");
		paymentplan.setRegularPaymentAmount(Double.valueOf(decimalFormat.format(regularPayment)));
		Double lastPayment = Double
				.valueOf(decimalFormat.format(calculateLastPayment(Double.valueOf(decimalFormat.format(regularPayment)),
						numberOfPayment, totalAmount)));
		paymentplan
				.setLastAmount(lastPayment);
		return paymentplanRepository.save(paymentplan);
	}

	/**
	 * calculateLastPayment is used to calcuate the last amount.
	 * 
	 * @param regularPayment
	 * @param numberOfPayment
	 * @param totalAmount
	 * @return last payment amount
	 */
	private Double calculateLastPayment(Double regularPayment, Integer numberOfPayment, Double totalAmount) {
		if (regularPayment * numberOfPayment == totalAmount) {
			return 0d;
		} else {
			return totalAmount - (regularPayment * (numberOfPayment - 1));
		}
	}

}
