package com.bottomline.paymentplan.service;

import java.util.List;

import com.bottomline.paymentplan.model.Paymentplan;

public interface PaymentplanService {

	/**
	 * getAllPaymentplans is used to get all the payment plan details
	 * 
	 * @return list of all payment plan details
	 */
	List<Paymentplan> getAllPaymentplans();

	/**
	 * getPaymentplan is used to get the selected payment plan
	 * 
	 * @param paymentId
	 * @return selected payment plan
	 */
	Paymentplan getPaymentplan(long paymentId);

	/**
	 * createPaymentPlan is used to create a payment plan
	 * 
	 * @param totalAmount
	 * @param numberOfPayment
	 * @return created payment plan details
	 */
	Paymentplan createPaymentPlan(Double totalAmount, Integer numberOfPayment);

}
