package com.bottomline.paymentplan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentplanApplicationTests {

	@Test
	void contextLoads() {
	}

}
